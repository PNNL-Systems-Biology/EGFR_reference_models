All files are UNIX-formatted text files.  Windows and MS-DOS machines will not display correctly
unless the text files are first converted.  To do so, replace all line feeds (LF) with a pair of
line-feed and carriage-return (CR-LF).  
